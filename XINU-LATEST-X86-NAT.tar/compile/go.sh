make clean
make 
scp xinu cheng75@sslab01.cs.purdue.edu:~/tmp
sudo cp xinu /srv/tftpboot/xinu133.boot
sudo cp xinu /srv/tftpboot/xinu155.boot
sudo cp xinu /srv/tftpboot/txinu202.boot
